using UnityEngine;

public class PipeSpawnerScript : MonoBehaviour
{
    public GameObject pipe; // The pipe prefab to spawn
    public float spawnRate = 2f; // Time interval between pipe spawns
    private float timer = 0f; // Timer to track spawn intervals
    public float heightOffset = 5f; // Vertical offset for pipe spawning
    public float screenHeight = 10f; // Screen height in world units for clamping pipes

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= spawnRate)
        {
            SpawnPipe();
            timer = 0f;
        }
    }

    void SpawnPipe()
    {
        // Calculate the vertical range for pipe spawning
        float lowestPoint = transform.position.y - (screenHeight / 2) + heightOffset;
        float highestPoint = transform.position.y + (screenHeight / 2) - heightOffset;

        // Instantiate the pipe within the defined vertical range
        Vector3 spawnPosition = new Vector3(transform.position.x, Random.Range(lowestPoint, highestPoint), 0);
        Instantiate(pipe, spawnPosition, Quaternion.identity);
    }
}
